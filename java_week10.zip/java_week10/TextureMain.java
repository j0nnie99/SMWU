class TextureMain {
	
	public static void main(String[] args) {
		new TextureTest();
	}
}