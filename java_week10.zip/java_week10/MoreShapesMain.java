class MoreShapesMain
{
	public static void main(String[] args) {
		MoreShapes ms1 = new MoreShapes();
	}
}