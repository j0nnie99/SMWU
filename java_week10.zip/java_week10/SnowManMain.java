class SnowManMain{
	public static void main(String args[]) {
		SnowManFace snow = new SnowManFace("SnowMan: 윤정인");
	}
}
