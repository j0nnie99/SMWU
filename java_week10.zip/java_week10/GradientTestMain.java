class GradientTestMain {
	
	public static void main(String[] args) {
		new GradientTest();
	}
	
}