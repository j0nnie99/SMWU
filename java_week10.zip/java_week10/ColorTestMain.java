class ColorTestMain {
	
	public static void main(String[] args) {
		ColorTest s1 = new ColorTest();
	}
	
}