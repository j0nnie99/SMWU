class DrawTreeFrameMain
{
	public static void main(String[] args)
	{
		DrawTree dt = new DrawTree("DrawTree: 윤정인");
	}
}