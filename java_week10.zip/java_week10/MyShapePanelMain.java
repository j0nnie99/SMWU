class MyShapePanelMain{
	public static void main(String args[]) {
		LineShapes ls = new LineShapes();
	}
}
