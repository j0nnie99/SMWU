class BasicPaintMain{
	public static void main(String args[]) {
		BasicPaint p = new BasicPaint("Basic Paint: 윤정인");
	}
}
