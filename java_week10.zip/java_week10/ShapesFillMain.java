class ShapesFillMain {
	
	public static void main(String[] args) {
		ShapesFill sh = new ShapesFill();
	}
	
}