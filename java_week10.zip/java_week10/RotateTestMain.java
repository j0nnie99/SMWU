class RotateTestMain {
	
	public static void main(String[] args) {
		new RotateTest();
	}
	
}