class ColorChooserMain {
	
	public static void main(String args[]) {
		ColorChooser cc = new ColorChooser();
	}
	
}